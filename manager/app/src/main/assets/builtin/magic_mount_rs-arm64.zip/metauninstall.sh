#!/system/bin/sh
# Copyright (C) 2026 meta-magic_mount-rs developers
# SPDX-License-Identifier: GPL-v3

############################################
# mm-mm metauninstall.sh
############################################

exit 0
